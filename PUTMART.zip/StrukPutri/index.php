<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Struk</title>
</head>
<style>	
		*{
			font-family: 	sans-serif;
		}
</style>
<?php 
	$con = mysqli_connect('localhost','root','','java_putri');
	$kode = $_GET['kode'];
	$sqlTR = "SELECT * FROM table_transaksi WHERE id_transaksi = '$kode'";
	$queryTR = mysqli_query($con,$sqlTR);
	$dataTR = mysqli_fetch_assoc($queryTR);
 ?>
<body style="padding: 40px;">
	<h2>PutMart</h2>
	<p>Jalan Wikrama bagus no.04</p>
	<hr>
	<p>Kode Transaksi : <?php echo $_GET['kode'] ?></p>
	<p>Tanggal Transaksi : <?php echo $dataTR['tanggal_transaksi'] ?></p>
	<table border="0" cellpadding="10" cellspacing="0" style="border-collapse: collapse;" width="100%" align="center">
		<thead>
			<tr>
				<td>Barang</td>
				<td>Jumlah</td>
				<td>Sub Total</td>
			</tr>
		</thead>
	<?php 
		$sql = "SELECT * FROM view_detail_transaksi WHERE id_transaksi = '$kode'";
		$query = mysqli_query($con,$sql);
		$no = 1;
		$total = 0;
		while($data = mysqli_fetch_assoc($query)){
		$total = $total + $data['sub_total'];
	 ?>
		<tbody>
			<tr>
				<td><?php echo $data['nama_barang'] ?></td>
				<td><?php echo number_format($data['jumlah_beli']) ?></td>
				<td><?php echo "Rp.".number_format($data['sub_total']) ?></td>
			</tr>
		</tbody>
	 <?php $no++; } ?>
	 	<tbody>
	 		<tr  style="border-top:1px solid black;">
		 		<td></td>
		 		<td>Total     :</td>
		 		<td><?php echo "Rp.".number_format($total); ?></td>
		 	</tr>
		 	<tr>
	 			<td></td>
	 			<td>Dibayar   : </td>
	 			<td><?php echo "Rp.".number_format($dataTR['bayar']); ?></td>
	 		</tr>
		 	<tr>
	 			<td></td>
	 			<td>Kembalian : </td>
	 			<td><?php echo "Rp.".number_format($dataTR['kembalian']); ?></td>
	 		</tr>
	 	</tbody>
	 </table>
</body>
<script>	
		window.print();
</script>
</html>