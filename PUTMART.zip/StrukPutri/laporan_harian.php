<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Struk</title>
</head>
<style>	
		*{
			font-family: 	sans-serif;
		}
</style>
<?php 
	$date = date('d');
	$con = mysqli_connect('localhost','root','','java_putri');
	$sqlTR = "SELECT * FROM table_transaksi WHERE day(tanggal_transaksi) = '$date'";
	$queryTR = mysqli_query($con,$sqlTR);
 ?>
<body style="padding: 40px;">
	<h2>PutMart</h2>
	<p>Jalan Wikrama bagus no.04</p>
	<hr>
	<table border="0" cellpadding="10" cellspacing="0" style="border-collapse: collapse;" width="100%" align="center">
		<tr>
			<th>ID TRANSAKSI</th>
			<th>Total</th>
			<th>Bayar</th>
			<th>Kembalian</th>
		</tr>
		<?php 
		$total = 0;
		while($dataTR = mysqli_fetch_assoc($queryTR)){
			$total = $total + $dataTR['total'];
		?>
		<tr>
			<th><?php echo $dataTR['id_transaksi'] ?></th>
			<th><?php echo $dataTR['total'] ?></th>
			<th><?php echo $dataTR['bayar'] ?></th>
			<th><?php echo $dataTR['kembalian'] ?></th>
		</tr>
		<?php } ?>
		<tr>
			<th colspan="1"></th>
			<th colspan="2">Total Uang :</th>
			<th><?php echo $total ?></th>
		</tr>
	</table>
</body>
<script>	
		window.print();
</script>
</html>