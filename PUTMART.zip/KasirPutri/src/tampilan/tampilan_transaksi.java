/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tampilan;

import java.awt.Desktop;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author PutriSalmaWulandari
 */
public class tampilan_transaksi extends javax.swing.JFrame {
    public Statement st;
    public ResultSet rs;
    public DefaultTableModel tabmodel,tabmodel2;
    public PreparedStatement pst;
    Connection con = koneksi.koneksi.Conn();
    /**
     * Creates new form tampilan_transaksi
     */
    public tampilan_transaksi() {
        initComponents();
        setLocationRelativeTo(this);
        autokode();
        model();
        tampilData();
        modelKeranjang();
        autokodeTRANSAKSI();
        tampilDataKeranjang();
        hitungKeranjang();
    }
    
    protected void model(){
        Object[] judul = {"No","Kode","Nama","Harga","Stok"};
//        tabmodel = new DefaultTableModel(null,judul);  ?
        tabmodel = new DefaultTableModel(null,judul){
            @Override
            public boolean isCellEditable(int row,int column)
            {
                return false;
            }
        };
        tableBarang.setModel(tabmodel); 
    }
    
    protected void modelKeranjang(){
        Object[] judul = {"No","ID Antrian","ID Barang","Jumlah beli","Sub total"};
        tabmodel2 = new DefaultTableModel(null,judul){
            @Override
            public boolean isCellEditable(int row,int column)
            {
                return false;
            }
        };  
        tableKeranjang.setModel(tabmodel2); 
    }
    
    private void tampilData()
     {
         try{
            int no = 1;
            st = con.createStatement();
            tabmodel.getDataVector().removeAllElements();
            tabmodel.fireTableDataChanged();
            rs = st.executeQuery("SELECT * FROM table_barang WHERE stok_barang > 0");
            while(rs.next()){
                Object [] data = {
                    no,
                    rs.getString("id_barang"),
                    rs.getString("nama_barang"),
                    rs.getString("harga_barang"),
                    rs.getString("stok_barang"),
                };
                tabmodel.addRow(data);
                no++;
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
     }
    
    private void tampilDataKeranjang()
     {
         try{
            int no = 1;
            st = con.createStatement();
            tabmodel2.getDataVector().removeAllElements();
            tabmodel2.fireTableDataChanged();
            rs = st.executeQuery("SELECT * FROM table_pretransaksi WHERE id_transaksi = '"+ TF_TRANSAKSI.getText() +"'");
            while(rs.next()){
                Object [] data = {
                    no,
                    rs.getString("id_pretransaksi"),
                    rs.getString("id_barang"),
                    rs.getString("jumlah_beli"),
                    rs.getString("sub_total"),
                };
                tabmodel2.addRow(data);
                no++;
                
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
     }
    
    
    private void autokode()
    {
        try {
            String kode;
            st = con.createStatement();
            rs = st.executeQuery("SELECT COUNT(id_pretransaksi) as jumlah FROM table_pretransaksi");
            if (rs.next()) {
                String jumlah = rs.getString("jumlah");
                int jum = Integer.parseInt(jumlah);
                if (jum > 0) {
                    st = con.createStatement();
                    rs = st.executeQuery("SELECT MAX(id_pretransaksi) as maksimal FROM table_pretransaksi");
                    if (rs.next()) {
                        String kode_maksimal = rs.getString("maksimal");
                        String ambil_kode = kode_maksimal.substring(2);
                        int amkode = Integer.parseInt(ambil_kode);
                        int kodenya = amkode + 1;
                        if (ambil_kode.length() == 3) {
                            kode = "PR00"+kodenya;
                        }else if(ambil_kode.length() == 2){
                            kode = "PR0"+kodenya;
                        }else{
                            kode = "PR00"+kodenya;
                        }
                        
                        TF_ANTRIAN.setText(kode);
                    }
                }else{
                    kode = "PR001";
                    TF_ANTRIAN.setText(kode);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            Logger.getLogger(tampilan_menu_barang.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void autokodeTRANSAKSI()
    {
        try {
            String kode;
            st = con.createStatement();
            rs = st.executeQuery("SELECT COUNT(id_transaksi) as jumlah FROM table_transaksi");
            if (rs.next()) {
                String jumlah = rs.getString("jumlah");
                int jum = Integer.parseInt(jumlah);
                if (jum > 0) {
                    st = con.createStatement();
                    rs = st.executeQuery("SELECT MAX(id_transaksi) as maksimal FROM table_transaksi");
                    if (rs.next()) {
                        String kode_maksimal = rs.getString("maksimal");
                        String ambil_kode = kode_maksimal.substring(2);
                        int amkode = Integer.parseInt(ambil_kode);
                        int kodenya = amkode + 1;
                        if (ambil_kode.length() == 3) {
                            kode = "TR00"+kodenya;
                        }else if(ambil_kode.length() == 2){
                            kode = "TR0"+kodenya;
                        }else{
                            kode = "TR00"+kodenya;
                        }
                        
                        TF_TRANSAKSI.setText(kode);
                    }
                }else{
                    kode = "TR001";
                    TF_TRANSAKSI.setText(kode);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            Logger.getLogger(tampilan_menu_barang.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    Boolean cekNumber(String string){
        try {
            int l = Integer.parseInt(string);
            return true;
        }
        catch (NumberFormatException e){
            return false;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        kembBtn = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableKeranjang = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        TF_ANTRIAN = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        asd = new javax.swing.JLabel();
        TF_NAMA = new javax.swing.JTextField();
        asd1 = new javax.swing.JLabel();
        TF_HARGA = new javax.swing.JTextField();
        asd2 = new javax.swing.JLabel();
        TF_STOK = new javax.swing.JTextField();
        btnByar = new javax.swing.JButton();
        asd3 = new javax.swing.JLabel();
        TF_SUB = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableBarang = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        asd4 = new javax.swing.JLabel();
        TF_TOTAL_HARGA = new javax.swing.JTextField();
        asd5 = new javax.swing.JLabel();
        TF_BAYAR = new javax.swing.JTextField();
        asd6 = new javax.swing.JLabel();
        TF_KEMBALIAN = new javax.swing.JTextField();
        btnKeranjang1 = new javax.swing.JButton();
        asd7 = new javax.swing.JLabel();
        TF_ID = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        TF_TRANSAKSI = new javax.swing.JTextField();
        asd8 = new javax.swing.JLabel();
        TF_STOKBAR = new javax.swing.JTextField();
        btnBatal = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(41, 152, 224));

        kembBtn.setBackground(new java.awt.Color(255, 255, 255));
        kembBtn.setFont(new java.awt.Font("Quicksand", 0, 14)); // NOI18N
        kembBtn.setForeground(new java.awt.Color(41, 152, 224));
        kembBtn.setText("Kembali");
        kembBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembBtnMouseClicked(evt);
            }
        });
        kembBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembBtnActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Quicksand", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Transaksi");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(1101, Short.MAX_VALUE)
                .addComponent(kembBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(20, 20, 20)
                    .addComponent(jLabel8)
                    .addContainerGap(1117, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(kembBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addContainerGap(27, Short.MAX_VALUE)
                    .addComponent(jLabel8)
                    .addGap(13, 13, 13)))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 70));

        tableKeranjang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableKeranjang.setEnabled(false);
        tableKeranjang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableKeranjangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableKeranjang);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 120, 310, 390));

        jLabel5.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(41, 152, 224));
        jLabel5.setText("Keranjang");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 90, -1, -1));

        TF_ANTRIAN.setEditable(false);
        TF_ANTRIAN.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_ANTRIAN.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.add(TF_ANTRIAN, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 140, 270, 40));

        jLabel7.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        jLabel7.setText("ID ANTRIAN");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 120, -1, -1));

        asd.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        asd.setForeground(new java.awt.Color(102, 102, 102));
        asd.setText("Nama Barang");
        jPanel1.add(asd, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 190, -1, -1));

        TF_NAMA.setEditable(false);
        TF_NAMA.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_NAMA.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.add(TF_NAMA, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 210, 270, 40));

        asd1.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        asd1.setForeground(new java.awt.Color(102, 102, 102));
        asd1.setText("Harga");
        jPanel1.add(asd1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, -1, -1));

        TF_HARGA.setEditable(false);
        TF_HARGA.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_HARGA.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.add(TF_HARGA, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 280, 270, 40));

        asd2.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        asd2.setForeground(new java.awt.Color(102, 102, 102));
        asd2.setText("Jumlah beli");
        jPanel1.add(asd2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 330, -1, -1));

        TF_STOK.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_STOK.setForeground(new java.awt.Color(51, 51, 51));
        TF_STOK.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TF_STOKKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TF_STOKKeyTyped(evt);
            }
        });
        jPanel1.add(TF_STOK, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 350, 270, 40));

        btnByar.setBackground(new java.awt.Color(41, 152, 224));
        btnByar.setFont(new java.awt.Font("Quicksand", 0, 14)); // NOI18N
        btnByar.setForeground(new java.awt.Color(255, 255, 255));
        btnByar.setText("Bayar");
        btnByar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnByarActionPerformed(evt);
            }
        });
        jPanel1.add(btnByar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 600, 140, 40));

        asd3.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        asd3.setForeground(new java.awt.Color(102, 102, 102));
        asd3.setText("Sub total");
        jPanel1.add(asd3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 400, -1, -1));

        TF_SUB.setEditable(false);
        TF_SUB.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_SUB.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.add(TF_SUB, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 420, 270, 40));

        jLabel6.setFont(new java.awt.Font("Quicksand", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(41, 152, 224));
        jLabel6.setText("Pembayaran");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 530, -1, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 570, 230, -1));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 130, -1, 380));

        tableBarang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableBarang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableBarangMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tableBarang);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 320, 390));

        jLabel9.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(41, 152, 224));
        jLabel9.setText("Daftar Barang");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        asd4.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        asd4.setForeground(new java.awt.Color(102, 102, 102));
        asd4.setText("Total Harga");
        jPanel1.add(asd4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 580, -1, -1));

        TF_TOTAL_HARGA.setEditable(false);
        TF_TOTAL_HARGA.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_TOTAL_HARGA.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.add(TF_TOTAL_HARGA, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 600, 300, 40));

        asd5.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        asd5.setForeground(new java.awt.Color(102, 102, 102));
        asd5.setText("Uang Dibayar");
        jPanel1.add(asd5, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 580, -1, -1));

        TF_BAYAR.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_BAYAR.setForeground(new java.awt.Color(51, 51, 51));
        TF_BAYAR.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TF_BAYARKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TF_BAYARKeyTyped(evt);
            }
        });
        jPanel1.add(TF_BAYAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 600, 300, 40));

        asd6.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        asd6.setForeground(new java.awt.Color(102, 102, 102));
        asd6.setText("Kembalian");
        jPanel1.add(asd6, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 580, -1, -1));

        TF_KEMBALIAN.setEditable(false);
        TF_KEMBALIAN.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_KEMBALIAN.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.add(TF_KEMBALIAN, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 600, 300, 40));

        btnKeranjang1.setBackground(new java.awt.Color(41, 152, 224));
        btnKeranjang1.setFont(new java.awt.Font("Quicksand", 0, 14)); // NOI18N
        btnKeranjang1.setForeground(new java.awt.Color(255, 255, 255));
        btnKeranjang1.setText("Tambahkan");
        btnKeranjang1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKeranjang1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnKeranjang1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 470, 140, 40));

        asd7.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        asd7.setForeground(new java.awt.Color(102, 102, 102));
        asd7.setText("Stok Barang");
        jPanel1.add(asd7, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 260, -1, -1));

        TF_ID.setEditable(false);
        TF_ID.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_ID.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.add(TF_ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 210, 250, 40));

        jLabel10.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(102, 102, 102));
        jLabel10.setText("ID TRANSAKSI");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 120, -1, -1));

        TF_TRANSAKSI.setEditable(false);
        TF_TRANSAKSI.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_TRANSAKSI.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.add(TF_TRANSAKSI, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 140, 250, 40));

        asd8.setFont(new java.awt.Font("Quicksand", 1, 12)); // NOI18N
        asd8.setForeground(new java.awt.Color(102, 102, 102));
        asd8.setText("ID Barang");
        jPanel1.add(asd8, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 190, -1, -1));

        TF_STOKBAR.setEditable(false);
        TF_STOKBAR.setFont(new java.awt.Font("Quicksand", 1, 14)); // NOI18N
        TF_STOKBAR.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.add(TF_STOKBAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 280, 250, 40));

        btnBatal.setBackground(new java.awt.Color(255, 0, 51));
        btnBatal.setFont(new java.awt.Font("Quicksand", 0, 14)); // NOI18N
        btnBatal.setForeground(new java.awt.Color(255, 255, 255));
        btnBatal.setText("Reset");
        btnBatal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBatalMouseClicked(evt);
            }
        });
        btnBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBatalActionPerformed(evt);
            }
        });
        jPanel1.add(btnBatal, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 470, 120, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 710));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void kembBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembBtnMouseClicked
        
    }//GEN-LAST:event_kembBtnMouseClicked

    private void kembBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembBtnActionPerformed
        tampilan_utama menu = new tampilan_utama();
        menu.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_kembBtnActionPerformed

    private void tableKeranjangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableKeranjangMouseClicked
        
    }//GEN-LAST:event_tableKeranjangMouseClicked

    private void btnByarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnByarActionPerformed
        if (TF_BAYAR.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Bayar Terlebih Dahulu");
        }else{
            int total_harga,total_bayar,total_kembalian;
            total_harga = Integer.parseInt(TF_TOTAL_HARGA.getText());
            total_bayar = Integer.parseInt(TF_BAYAR.getText());
            if (total_bayar < total_harga) {
                JOptionPane.showMessageDialog(null, "Uang kurang!");
            }else{
                int kembalian = total_bayar - total_harga;
                TF_KEMBALIAN.setText(String.valueOf(kembalian));
                int jawaban;
                if ((jawaban = JOptionPane.showConfirmDialog(null,"Yakin Selesaikan Transaksi?", "Konfirmasi", JOptionPane.YES_NO_OPTION)) == 0) {
                    try{
                    st = con.createStatement();
                    String sql = "INSERT INTO table_transaksi VALUES('"+ TF_TRANSAKSI.getText() +"',null,'"+ total_harga +"','"+ total_bayar +"','"+ kembalian +"')";
                    st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null, "TRANSAKSI SELESAI");
                    try {
                        Desktop dekstop = Desktop.getDesktop();
                        dekstop.browse(new URL("http://localhost/Native&OOP/StrukPutri/index.php?kode="+TF_TRANSAKSI.getText()).toURI());
                        resetBeli();
                        kembBtn.setVisible(true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    }catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }
    }//GEN-LAST:event_btnByarActionPerformed

    private void tableBarangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableBarangMouseClicked
        int baris = tableBarang.getSelectedRow();
        TF_NAMA.setText(tableBarang.getModel().getValueAt(baris, 2).toString());
        TF_HARGA.setText(tableBarang.getModel().getValueAt(baris, 3).toString());
        TF_ID.setText(tableBarang.getModel().getValueAt(baris, 1).toString());
        TF_STOKBAR.setText(tableBarang.getModel().getValueAt(baris, 4).toString());
        hitung();
    }//GEN-LAST:event_tableBarangMouseClicked

    private void btnKeranjang1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKeranjang1ActionPerformed
        if(TF_NAMA.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Pilih Barang Terlebih dahulu");
        }else{
            if(!cekNumber(TF_STOK.getText())){
                JOptionPane.showMessageDialog(null, "Jumlah beli harus angka!");
            }else{
            String id_antrian,nama_barang,harga_barang,jumlah_beli,sub_total,id_transaksi,id_barang,stok_barang;
            id_antrian = TF_ANTRIAN.getText();
            nama_barang = TF_NAMA.getText();
            harga_barang = TF_HARGA.getText();
            jumlah_beli = TF_STOK.getText().toString();
            sub_total = TF_SUB.getText();
            id_transaksi = TF_TRANSAKSI.getText();
            id_barang = TF_ID.getText();
            stok_barang = TF_STOKBAR.getText();
            tambahKeranjang(id_antrian, id_transaksi, id_barang, jumlah_beli, sub_total,stok_barang);
            hitungKeranjang();
            kembBtn.setVisible(false);
            }
        }
    }//GEN-LAST:event_btnKeranjang1ActionPerformed
    private void tambahKeranjang(String id_antrian,String id_transaksi,String id_barang,String jumlah_beli,String sub_total,String stok_bar)
    {
        try{
            if (Integer.parseInt(stok_bar) < Integer.parseInt(jumlah_beli)) {
                JOptionPane.showMessageDialog(null, "Stok Kurang!");
            }else{
                st = con.createStatement();
                rs = st.executeQuery("SELECT COUNT(id_barang) AS cek FROM table_pretransaksi WHERE id_barang = '"+ id_barang +"' AND id_transaksi = '"+ id_transaksi +"' ");
                if (rs.next()) {
                    String cekdata = rs.getString("cek");
                    if (Integer.parseInt(cekdata) > 0) {
                        st = con.createStatement();
                        rs = st.executeQuery("SELECT * FROM table_pretransaksi WHERE id_barang = '"+ id_barang +"' AND id_transaksi = '"+ id_transaksi +"' ");
                        if (rs.next()) {
                           String pretran = rs.getString("id_pretransaksi");
                           String jumlah_lama = rs.getString("jumlah_beli");
                           String sub_total_lama = rs.getString("sub_total");
                           int total_baru = Integer.parseInt(jumlah_lama) + Integer.parseInt(jumlah_beli);
                           int sub_baru = Integer.parseInt(sub_total) + Integer.parseInt(sub_total_lama);
                           st = con.createStatement();
                           st.executeUpdate("UPDATE table_pretransaksi SET jumlah_beli = '"+ String.valueOf(total_baru) +"',sub_total = '"+ String.valueOf(sub_baru) +"' WHERE id_pretransaksi = '"+ pretran +"'");
                           JOptionPane.showMessageDialog(null, "Ditambahkan di keranjang");
                           resetBeli();
                        }
                    }else{
                        st = con.createStatement();
                        String sql = "INSERT INTO table_pretransaksi VALUES('"+ id_antrian +"','"+ id_transaksi +"','"+ id_barang +"','"+ jumlah_beli +"','"+ sub_total +"')";
                        st.executeUpdate(sql);
                        JOptionPane.showMessageDialog(null, "Ditambahkan di keranjang");
                        resetBeli();
                    }
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    private void hitungKeranjang()
    {
        try{
            String sql = "SELECT SUM(sub_total) as total_harga FROM table_pretransaksi WHERE id_transaksi = '"+ TF_TRANSAKSI.getText() +"'";
            st = con.createStatement();
            rs = st.executeQuery(sql);
            if (rs.next()) {
                String total_harga = rs.getString("total_harga");
                if (total_harga == null)
                {
                    TF_TOTAL_HARGA.setText("0");
                }else{
                    TF_TOTAL_HARGA.setText(total_harga);
                }
            }
        }catch(Exception e)
        {
            
        }
        
    }
    
    private void resetBeli(){
        TF_ANTRIAN.setText("");
        TF_NAMA.setText("");
        TF_HARGA.setText("");
        TF_STOK.setText("");
        TF_SUB.setText("");
        TF_TRANSAKSI.setText("");
        TF_ID.setText("");
        TF_STOKBAR.setText("");
        autokode();
        autokodeTRANSAKSI();
        tampilData();
        tampilDataKeranjang();
        hitungKeranjang();
        TF_TOTAL_HARGA.setText("");
        TF_BAYAR.setText("");
        TF_KEMBALIAN.setText("");
    }
    
    private void TF_STOKKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_STOKKeyReleased
        char a = evt.getKeyChar();
        if (!(Character.isDigit(a)) || (a==KeyEvent.VK_BACK_SPACE) || (a==KeyEvent.VK_DELETE)) {
            evt.consume();
        }
        hitung();
    }//GEN-LAST:event_TF_STOKKeyReleased

    private void btnBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBatalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBatalActionPerformed

    private void btnBatalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBatalMouseClicked
        resetBeli();
    }//GEN-LAST:event_btnBatalMouseClicked

    private void TF_BAYARKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BAYARKeyReleased
        char a = evt.getKeyChar();
        if (!(Character.isDigit(a)) || (a==KeyEvent.VK_BACK_SPACE) || (a==KeyEvent.VK_DELETE)) {
            evt.consume();
        }
        int total_harga,total_bayar,total_kembalian;
        total_harga = Integer.parseInt(TF_TOTAL_HARGA.getText());
        total_bayar = Integer.parseInt(TF_BAYAR.getText());
        int kembalian = total_bayar - total_harga;
        TF_KEMBALIAN.setText(String.valueOf(kembalian));
    }//GEN-LAST:event_TF_BAYARKeyReleased

    private void TF_STOKKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_STOKKeyTyped
        char a = evt.getKeyChar();
        if (!(Character.isDigit(a)) || (a==KeyEvent.VK_BACK_SPACE) || (a==KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_TF_STOKKeyTyped

    private void TF_BAYARKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BAYARKeyTyped
        char a = evt.getKeyChar();
        if (!(Character.isDigit(a)) || (a==KeyEvent.VK_BACK_SPACE) || (a==KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_TF_BAYARKeyTyped
    
    private void hitung()
    {
        int harga,subtotal,jumbeli;
        if (TF_STOK.getText().toString().equals("")) {
            TF_SUB.setText("");
        }else{
            harga = Integer.parseInt(TF_HARGA.getText());
            jumbeli = Integer.parseInt(TF_STOK.getText());
            subtotal = harga * jumbeli;
            String hasil = String.valueOf(subtotal);
            TF_SUB.setText(hasil);
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tampilan_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tampilan_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tampilan_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tampilan_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tampilan_transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField TF_ANTRIAN;
    private javax.swing.JTextField TF_BAYAR;
    private javax.swing.JTextField TF_HARGA;
    private javax.swing.JTextField TF_ID;
    private javax.swing.JTextField TF_KEMBALIAN;
    private javax.swing.JTextField TF_NAMA;
    private javax.swing.JTextField TF_STOK;
    private javax.swing.JTextField TF_STOKBAR;
    private javax.swing.JTextField TF_SUB;
    private javax.swing.JTextField TF_TOTAL_HARGA;
    private javax.swing.JTextField TF_TRANSAKSI;
    private javax.swing.JLabel asd;
    private javax.swing.JLabel asd1;
    private javax.swing.JLabel asd2;
    private javax.swing.JLabel asd3;
    private javax.swing.JLabel asd4;
    private javax.swing.JLabel asd5;
    private javax.swing.JLabel asd6;
    private javax.swing.JLabel asd7;
    private javax.swing.JLabel asd8;
    private javax.swing.JButton btnBatal;
    private javax.swing.JButton btnByar;
    private javax.swing.JButton btnKeranjang1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JButton kembBtn;
    private javax.swing.JTable tableBarang;
    private javax.swing.JTable tableKeranjang;
    // End of variables declaration//GEN-END:variables
}
