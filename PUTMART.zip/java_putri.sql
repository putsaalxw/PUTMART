-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 10 Mei 2018 pada 04.16
-- Versi Server: 10.1.24-MariaDB
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `java_putri`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_barang`
--

CREATE TABLE `table_barang` (
  `id_barang` varchar(6) NOT NULL,
  `nama_barang` varchar(40) NOT NULL,
  `harga_barang` int(10) UNSIGNED NOT NULL,
  `stok_barang` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `table_barang`
--

INSERT INTO `table_barang` (`id_barang`, `nama_barang`, `harga_barang`, `stok_barang`) VALUES
('BR001', 'Teh Gelas', 1000, 0),
('BR002', 'Mie Sarimi', 2500, 86),
('BR003', 'Teh susu', 1000, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_pengguna`
--

CREATE TABLE `table_pengguna` (
  `username` varchar(25) NOT NULL,
  `password` varchar(25) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `table_pengguna`
--

INSERT INTO `table_pengguna` (`username`, `password`) VALUES
('admin', 'admin'),
('putri', 'putri');

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_pretransaksi`
--

CREATE TABLE `table_pretransaksi` (
  `id_pretransaksi` varchar(6) NOT NULL,
  `id_transaksi` varchar(6) NOT NULL,
  `id_barang` varchar(6) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `sub_total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `table_pretransaksi`
--

INSERT INTO `table_pretransaksi` (`id_pretransaksi`, `id_transaksi`, `id_barang`, `jumlah_beli`, `sub_total`) VALUES
('PR001', 'TR001', 'BR002', 4, 10000),
('PR002', 'TR002', 'BR003', 3, 3000),
('PR003', 'TR003', 'BR003', 3, 3000),
('PR004', 'TR004', 'BR003', 1, 1000),
('PR005', 'TR005', 'BR003', 1, 1000),
('PR006', 'TR006', 'BR003', 2, 2000),
('PR007', 'TR006', 'BR002', 4, 10000),
('PR008', 'TR006', 'BR001', 12, 12000);

--
-- Trigger `table_pretransaksi`
--
DELIMITER $$
CREATE TRIGGER `beli_barang` AFTER INSERT ON `table_pretransaksi` FOR EACH ROW UPDATE table_barang
SET stok_barang = stok_barang - NEW.jumlah_beli
WHERE id_barang = new.id_barang
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_transaksi`
--

CREATE TABLE `table_transaksi` (
  `id_transaksi` varchar(6) NOT NULL,
  `tanggal_transaksi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total` int(11) NOT NULL,
  `bayar` int(10) UNSIGNED NOT NULL,
  `kembalian` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `table_transaksi`
--

INSERT INTO `table_transaksi` (`id_transaksi`, `tanggal_transaksi`, `total`, `bayar`, `kembalian`) VALUES
('TR001', '2018-05-09 11:53:23', 10000, 10000, 0),
('TR002', '2018-05-09 11:54:05', 3000, 3000, 0),
('TR003', '2018-05-09 11:54:22', 3000, 3000, 0),
('TR004', '2018-05-09 11:56:44', 1000, 1000, 0),
('TR005', '2018-05-09 11:59:06', 1000, 10000, 9000),
('TR006', '2018-05-10 01:41:39', 24000, 25000, 1000);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_detail_transaksi`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_detail_transaksi` (
`nama_barang` varchar(40)
,`id_pretransaksi` varchar(6)
,`id_transaksi` varchar(6)
,`id_barang` varchar(6)
,`jumlah_beli` int(11)
,`sub_total` int(11)
);

-- --------------------------------------------------------

--
-- Struktur untuk view `view_detail_transaksi`
--
DROP TABLE IF EXISTS `view_detail_transaksi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_detail_transaksi`  AS  select `table_barang`.`nama_barang` AS `nama_barang`,`table_pretransaksi`.`id_pretransaksi` AS `id_pretransaksi`,`table_pretransaksi`.`id_transaksi` AS `id_transaksi`,`table_pretransaksi`.`id_barang` AS `id_barang`,`table_pretransaksi`.`jumlah_beli` AS `jumlah_beli`,`table_pretransaksi`.`sub_total` AS `sub_total` from (`table_barang` join `table_pretransaksi` on((`table_barang`.`id_barang` = `table_pretransaksi`.`id_barang`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `table_barang`
--
ALTER TABLE `table_barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `table_pengguna`
--
ALTER TABLE `table_pengguna`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `table_pretransaksi`
--
ALTER TABLE `table_pretransaksi`
  ADD PRIMARY KEY (`id_pretransaksi`);

--
-- Indexes for table `table_transaksi`
--
ALTER TABLE `table_transaksi`
  ADD PRIMARY KEY (`id_transaksi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
